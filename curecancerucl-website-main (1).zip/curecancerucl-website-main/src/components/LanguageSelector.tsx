// This component is no longer needed as we only support English
// Keeping as a stub to avoid breaking imports, but it renders nothing
export default function LanguageSelector() {
  return null;
}